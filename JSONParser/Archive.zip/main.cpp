//
//  main.cpp
//  JSONParser
//
//  Created by Yani Yankov on 11.05.22.
//

#include "JSONvaildation.hpp"
#include "JSONContainer.hpp"
#include "JSONReader.hpp"

void Menu()
{
    cout<<"MENU"<<'\n';
    cout<<'\n';
    cout<<"* print -------------------------> Prints the JSON file!"<<'\n';
    cout<<"* search <key> ------------------> Searchs for the object under the given key or path and saves it!"<<'\n';
    cout<<"* edit <object path> <value> ----> Edits the object value with the given one!"<<'\n';
    cout<<"* create <object path> <value> --> Creates a new object with the given value unless it already exists!"<<'\n';
    cout<<"* remove <object path> ----------> Removes the object unless it doesnt exists!"<<'\n';
    cout<<"* move <from> <to> --------------> Moves the value from \"from\" to \"to\"!"<<'\n';
    cout<<"* save <option> -----------------> Saves the JSON file in the file it's being opened!"<<'\n';
    cout<<"* saveft <option> <from> <to> ---> Saves the JSON file in the file it's being opened!"<<'\n';
    cout<<"* saveas <file> <option> --------> Saves the JSON file in new or existing file!"<<'\n';
    cout<<"                                   ! If option is \"minimal\" there would be no spaces between characters\n                                    when the file is saved!"<<'\n';
    cout<<"* saveasft <option> <from> <to> -> Saves the JSON file in the file it's being opened!"<<'\n';
    cout<<"* printsearched -----------------> Prints the searched objects!"<<'\n';
    cout<<"* printsearchedat <index> -------> Prints the searched objects at index!"<<'\n';
    cout<<"* savesearched <file> -----------> Saves the searched objects in a new or existing file!"<<'\n';
    cout<<"* savesearchedat <file> <index> -> Saves the searched objects at index in a new or existing file!"<<'\n';
    cout<<"* menu --------------------------> Shows MENU!"<<'\n';
    cout<<"* exit --------------------------> Exits the program!"<<'\n';
}
void run()
{
    JSONContainer container;
    while (container.IsEmpty())
    {
        std::string JSONFilePath="";
        cout<<"Enter JSONFilePath to open: ";
        getline(cin, JSONFilePath);
        if (JSONFilePath=="exit")
        {
            return ;
        }
        try {
            container.JSONContainerFill(JSONFilePath);

        } catch (const invalid_argument& e) {
            cerr<<e.what()<<'\n';
        }
    }

    cout<<'\n';
    container.PrintFilePath();
    cout<<'\n';
    Menu();
    while (true)
    {
        std::string command;
        cout<<'\n';
        cout<<"Enter command: ";
        getline(cin, command);
        //cout<<'\n';
        if (command=="menu")
        {
            Menu();
        }
        else if (command=="exit")
        {
            break;
        }
        else
        {
            try
            {
                container.CommandExcecutor(command);
            }
            catch (const invalid_argument& e)
            {
                cerr<<e.what()<<'\n';;
            }

        }

    }
}

int main() {
    run();
    JSONContainer container;
    while (container.IsEmpty())
    {
        std::string JSONFilePath="";
        cout<<"Enter JSONFilePath to open: ";
        getline(cin, JSONFilePath);
        if (JSONFilePath=="exit")
        {
            return 0;
        }
        try {
            container.JSONContainerFill(JSONFilePath);

        } catch (const invalid_argument& e) {
            cerr<<e.what()<<'\n';
        }
    }

    cout<<'\n';
    container.PrintFilePath();
    cout<<'\n';
    Menu();
    while (true)
    {
        std::string command;
        cout<<'\n';
        cout<<"Enter command: ";
        getline(cin, command);
        //cout<<'\n';
        if (command=="exit")
        {
            break;
        }
        else
        {
            try
            {
                container.CommandExcecutor(command);
            }
            catch (const invalid_argument& e)
            {
                cerr<<e.what()<<'\n';;
            }

        }

    }
//
//
//
//
//
////    string JSON="";
////
////    JSONReader reader;
////    JSON=reader.ReadJSON("JSONinput.txt");
////    cout<<JSON<<endl;
////    cout<<reader.isValid(JSON);
//    {
//    JSONContainer container;
//    container.JSONContainerFill("JSONinput.txt");
//    //container.printJSON();
////    cout<<endl;
////    container.print();
//      container.edit("\"Boolean\"", "null");
//    container.remove("\"Mobile\"");
// //   container.create("\"Name\"", "false");
//    container.create("\"Symbol\"", "'*'");
////    //container.edit("\"Symbol\"", "'l'");
//    container.search("\"Name\"");
//    container.move("\"Address\"", "\"Name\"");
////
////
//    container.edit("\"Address1\" \"current Address1\" \"AU1\"","[\"one\",\"two\"]");
//    container.edit("\"Symbol\"", "'p'");
////
////
//    container.remove("\"Pets\"");
//    container.search("\"Address1\" \"current Address1\" \"AU1\"");
//    container.create("\"Year\" \"Month\" \"Month\" \"Month\" \"Month\"", "{\"name\":false}");
//    container.create("\"Symbol\"", "'o'");
//    container.search("\"Symbol\"");
//  //  container.print();
//    container.edit("\"Year\" \"Month\" \"Month\" \"Month\"","[{\"A\":true},{\"B\":false}]");
//    container.search("\"Year\" \"Month\" \"Month\" \"Month\"");
//  //  container.print();
//    cout<<endl;
//    container.print();
//    container.printsearched();
//    container.printsearchedat(3);
//    //container.edit("\"Symbol\"", "{\"A\":2}");
//    container.CommandExcecutor("edit \"Symbol\" 5444");
//    container.print();
//}
////    for (JSONContainer::Iterator it=container.begin();it!=container.end();++it)
////    {
////        it.operator*().Print(cout);
////        cout<<'*'<<endl;
////    }
//   // container.saveas("SaveAsTest.txt","mal");
////   container1.print();
////    container1.save("t");
////    container[0]->Print(cout);
////        container.print();
//create "A" [{"B":{"K":true}},{"L":{"MAMA":{"BABA":56,"DQDO":1}}}]
    //SaveAsTest.txt
   

    return 0;
}
